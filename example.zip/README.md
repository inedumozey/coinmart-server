### Coinmart Backend Features
1. User auth and profile
2. Referral systems plus referral contest
3. 2fa authentication
4. App configurations
5. Transfer coin to internal users
6. Investment
7. Deposit cryptocurrency (automated with coinbase commerce webhook api)
8. Withdrawal
9. Notification systems
10. User payment

api documentation